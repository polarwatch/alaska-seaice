# chartjs 0.3.3

+ handle resize problems (#10),
+ actually edit scales,
+ works fine with flexdasboards with correct options

# chartjs 0.3.0

+ Rewrote the package using S3 methods for easier dispatch.